package com.registration.CRUD_Management;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudManagementApplication.class, args);
	}

}
