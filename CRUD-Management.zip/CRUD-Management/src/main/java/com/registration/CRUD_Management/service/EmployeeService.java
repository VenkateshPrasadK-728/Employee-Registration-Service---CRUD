package com.registration.CRUD_Management.service;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


import com.registration.CRUD_Management.model.Employee;

@Repository
public interface EmployeeService extends JpaRepository <Employee, Long> {

}
