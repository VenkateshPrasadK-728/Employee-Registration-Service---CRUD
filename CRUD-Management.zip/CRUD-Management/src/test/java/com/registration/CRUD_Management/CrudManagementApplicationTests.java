package com.registration.CRUD_Management;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
